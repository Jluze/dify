curl -d '@trigger.txt' $MM_NOTIFY_URL
